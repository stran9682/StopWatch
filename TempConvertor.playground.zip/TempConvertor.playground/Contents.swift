class TempConvertor {
    private var temp : Int
    
    init ( temp : Int ){
        self.temp = temp
    }
    
    static func tempBelowAbsoluteZero ( temp : Int , unit : String ) -> Bool {
        return (temp < -454 && unit == "F") || (temp < -273 && unit == "C")
    }
    
    static func convert ( temp : Int, unit : String = "F" ) -> Int {
        if tempBelowAbsoluteZero( temp : temp, unit : unit ) {
            return -1000
        }
        
        if ( unit == "F" ){
            return 5 * (temp - 32) / 9
        } else {
            return (9 * temp) / 5 + 32
        }
    }
}

let t = TempConvertor( temp: 10 )

print ( TempConvertor.convert(temp: 50) )
print ( TempConvertor.convert(temp: 10, unit: "C"))
print ( TempConvertor.convert(temp: -460, unit: "F"))
